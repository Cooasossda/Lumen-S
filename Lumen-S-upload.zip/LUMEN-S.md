# Lumen-S

Unofficial VIctory community fork targeting Series S on an Intel i5-13420H,
RTX 3050 Laptop 4 GiB, and 16 GiB RAM. No performance gains are claimed yet.

## Baseline

- Source: https://github.com/fxceless/victory-fork
- Revision: 32b31f753427704111c021353c33f198f622ff9b
- Local branch: lumen-s/series-s-low-vram
- Upstream history and credits retained. Remote pushing is disabled locally.
- Runtime source has not been modified.

## Initial source review

Candidate contributions, subject to source diffs and baseline measurements:

| Repository | Review priority |
| --- | --- |
| fxceless | Baseline; NVIDIA testing and memory synchronization |
| DexNom | Memory transfer batching, resource lifetimes, shader correctness |
| rorodev6 | Series S presentation and UI plane handling |
| VItoriaBr | Shader translation; check for already merged handlers |
| skornuta | Frametime CSV, wave translation and texture residency |
| Neptune_VI | Indirect draw validation and water readback |
| Belobug AMD | Portable correctness fixes; isolate AMD-specific workarounds |

The baseline already contains v_cvt_f32_f64, v_permlane16_b32 and
v_permlanex16_b32 handlers, VICTORY_LEVELS_ON_DEMAND, and VICTORY_TEXTURE_BACK.
Their existence is not proof that implementations match the other forks.
No complete patch equivalence audit has been performed yet.

## Storage-aware build

Initial free space: approximately 6.17 GiB. Use one checkout and one target
directory outside it; keep at least 1 GiB free. No user files are cleanup targets.

Build invocation uses the installed Rust 1.100.0 toolchain (upstream pins
1.98.1); record this deviation when interpreting results:

```powershell
$env:CARGO_PROFILE_RELEASE_DEBUG = '0'
$env:CARGO_INCREMENTAL = '0'
$env:CARGO_BUILD_JOBS = '2'
$env:CARGO_TARGET_DIR = 'C:\Users\coope\Downloads\Tiktok Gta6\Lumen-S-build'
cargo +stable build --locked --release -p victory --features diagnostics
```

## Benchmark procedure

Use the produced executable with --console series-s. Use separate cache and
save locations outside this checkout and outside the input game directories.
Never overwrite existing saves or change the supplied game files.
Record compiler, source revision, driver, settings, warm-up state, frame times,
memory use and visual correctness. Compare the same scene in at least three
runs; never interpret menus or loading screens as gameplay performance.
No FPS result is available until an actual game run is measured.

## Baseline result, 2026-11-25

The unchanged runtime source built successfully in 3m 46s with the command
above. The resulting executable also passed `run --help`. This verifies
compilation with Rust 1.100.0, not the upstream-pinned compiler.

A bounded Series S startup attempt was terminated by its 60-second monitor.
The owned process tree has stopped. Logs show title initialization and
unimplemented graphics-pipeline creation calls at slots 0x218 and 0x1c8.
This was not a repeatable gameplay scene: FPS, frame times, visual correctness,
peak VRAM, and driver-reset behavior remain unmeasured. No optimization or
30 FPS claim is supported by this attempt.

Measured directory file sizes after the attempt (excluding filesystem overhead):

| Directory | Bytes |
| --- | ---: |
| Source checkout (non-hidden files) | 15,415,813 |
| Release build artifacts | 355,005,568 |
| Separate runtime artifacts | 125,320,104 |

C: free space was 6,410,833,920 bytes (5.97 GiB). The baseline build fits
the available budget; future cache growth must still be monitored.

The separate user instruction marking the GTA6 download folder off-limits
must be resolved before any further use of that folder. Do not scan it or
follow links into it. A generic benchmark authorization must not silently
override this explicit folder protection.

Next work: clarify the binary-table licensing exception below; complete
the seven-fork history/diff audit; identify a permitted benchmark input;
then investigate the observed pipeline gaps before performance tuning.
No candidate patch has been ported, and no remote publication has occurred.

## Licensing

Keep LICENSE and all upstream contributor credits. Cargo declares
GPL-3.0-or-later for source. Upstream docs/asset-policy.md explicitly excludes
bcpack-tables.bin from that source license. Its redistribution permission
needs review before any publication; do not describe the entire checkout
as uniformly GPL-covered. No publication is authorized.
